// Definindo os parâmetros
var horario = new Date().toLocaleTimeString('pt-BR').toString().split(':').join('');
var horario2 = new Date().toLocaleTimeString('pt-BR');

var hoje = new Date().toLocaleDateString('pt-BR');
var parentFolder;
var calendar = java.util.Calendar.getInstance().getTime();


function beforeTaskSave(colleagueId, nextSequenceId, userList) {
    parentFolder = String(hAPI.getCardValue("parentFolder"));
    getAttach();

    DatasetFactory.getDataset("ds_upload_vertsign_manual", null, null, null);
}

function executeWebservice(params, callback) {

    var constraints = [];

    params.forEach(function (param) {
        constraints.push(DatasetFactory.createConstraint(param.name, param.value, param.value, ConstraintType.MUST));
    });

    if (constraints.length > 0) {
        var dsAux = DatasetFactory.getDataset("ds_auxiliar_vertsign", null, constraints, null);

        if (callback) {
            if (dsAux.rowsCount > 0) {
                if (dsAux.getValue(0, "Result") === "OK") {
                    callback();
                }
            }
        }
    }
}

function getAttach() {
    var anexos = new java.util.ArrayList();
    var docs = hAPI.listAttachments();

    if (docs.size() > 0) {
        for (var i = 0; i < docs.size(); i++) {
            var doc = docs.get(i);

            var idAnexo = doc.getDocumentId();
            var vrAnexo = doc.getVersion();
            var dsAnexo = doc.getDocumentDescription();

            // Cria o documento na pasta informada
            createDocument(doc, parentFolder);

            // Cria registro de formulario
            var nmArquivo = {
                name: "nmArquivo",
                value: dsAnexo
            };
            var codArquivo = {
                name: "codArquivo",
                value: idAnexo
            };
            var vrArquivo = {
                name: "vrArquivo",
                value: vrAnexo
            };
            var codPasta = {
                name: "codPasta",
                value: parentFolder
            };
            var codRemetente = {
                name: "codRemetente",
                value: "rafael.neves"
            };
            var emails = {
                name: "emailAssinantes",
                value: hAPI.getCardValue("mailSigner")
            };
            var formDescription = {
                name: "formDescription",
                value: dsAnexo
            };
            var status = {
                name: "status",
                value: "Enviando para assinatura"
            };
            var metodo = {
                name: "metodo",
                value: "create"
            };

            var dataEnvio = {
                name: "dataEnvio",
                value: hoje
            };
            var horaEnvio = {
                name: "horaEnvio",
                value: horario2
            };

            var constraints = [nmArquivo, codArquivo, vrArquivo, codPasta, codRemetente, emails, formDescription, status, metodo, dataEnvio, horaEnvio];

            executeWebservice(constraints, function () {
                log.info("Enviando documento para assinatura");
            })
        }

    } else {
        throw "É preciso anexar o documento para continuar o processo!";
    }
}

function createDocument(document, parentFolder) {

    if (document && parentFolder) {
        document.setParentDocumentId(Number(parentFolder));
        document.setVersionDescription("Processo: " + getValue("WKNumProces"));
        document.setExpires(false);
        document.setCreateDate(calendar);
        document.setInheritSecurity(true);
        document.setTopicId(1);
        document.setUserNotify(false);
        document.setValidationStartDate(calendar);
        document.setVersionOption("0");
        document.setUpdateIsoProperties(true);

        // Publica o documento
        hAPI.publishWorkflowAttachment(document);
    }
}