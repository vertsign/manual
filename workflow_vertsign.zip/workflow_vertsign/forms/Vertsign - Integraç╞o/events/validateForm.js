function validateForm(form){
	var parentFolder = form.getValue("parentFolder");
	var nmSigner = form.getValue("nmSigner");
	var mailSigner = form.getValue("mailSigner");
	var cpfSigner = form.getValue("cpfSigner");
	
	if(parentFolder  == "" || nmSigner == "" || mailSigner == "" || cpfSigner == ""){
		throw("Preencha todos os campos para continuar.")
	}
}